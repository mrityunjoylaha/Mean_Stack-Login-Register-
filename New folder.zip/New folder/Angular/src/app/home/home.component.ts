import {Component } from '@angular/core'
import {AuthenticationService, TokenPayload, UserDetails } from '../authentication.service'
import { Router } from '@angular/router'


@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['../profile/profile.component.css']
})

export class HomeComponent{
    details:UserDetails

    constructor(public auth: AuthenticationService,private router : Router){}
    
   

   
  

    ngOnInit() {
        this.auth.profile().subscribe(
            user => {
                this.details =user
            },
            err => {
                console.error(err)
            }
        )
    }
}